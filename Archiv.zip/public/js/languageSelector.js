document.getElementById('languageSelector').addEventListener('change', function () {
    const selectedLanguage = this.value;
    alert(`Sprachauswahl: ${selectedLanguage}`); // Später kann dies durch eine echte Sprachumschaltung ersetzt werden
});